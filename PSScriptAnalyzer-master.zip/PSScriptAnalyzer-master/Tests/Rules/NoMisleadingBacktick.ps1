New-NetLbfoTeam `
    -Name NetTeam `
    -TeamingMode SwitchIndependent `
    -TeamMembers Ethernet*
    
    
"this ` backtick is just fine, though"