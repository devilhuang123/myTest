Configuration SomeConfiguration
{
    Import-DscResource -ModuleName MyDSCResource
}