//Random c# script
int random() {
    Console.WriteLine("I don't belong in ps1");
    for (int i = 0; i < 5; i += 1)
        // Do nothing
    
    if (3 == 1)
        int a = 3;

    return 3;
}

void test() {
}

void test2() {
}

void test3() {
}

void test4() {
}

void test5() {
}

void test6() {
}